/*
* pagination.js 
*
* This code should be recoded according to WET standards  
*
* See http://flaviusmatis.github.io/simplePagination.js/ for
* more info on the plugin
*
* Ce code devrait �tre reprogramm� conform�ment aux normes de BOEW 
*
* Voir http://flaviusmatis.github.io/simplePagination.js/ pour 
* plus de d�tails sur le plugiciel
*
*
*/

// Function that displays a page and hide other pages / Fonction qui affiche une page et cache les autres 
function click(pageNumber)
{
	// Generate page number / G�n�rer un num�ro de page
	var page = "#page-"+pageNumber;
  
	// Hide other pages / Cacher les autres pages
	$('.hide-page').hide();
	
	// Show page selected / Afficher la page s�lectionn�e
	$(page).show();
}

// Display the first page when document is ready / Afficher la premi�re page d�s que le document est pr�t
$(document).ready(function() {

	// Variable to iterate through the child divs of div.paginate / Variable pour it�rer � travers les divs enfant de div.paginate
	var divs = $("div.paginate > div");
	
	// Check the page count / Garder le d�compte des pages
	var pageCount = 0;
	
	// Default value / Valeur par d�faut
	var numberOfItemOnPage = 5;
	
	// Number of items on each page from items-per-page-X class / Nombre d'items sur chaque page de la classe items-per-page-X
	$("[class*='items-per-page-']").each(function() {
		numberOfItemOnPage = parseInt(this.className.split('items-per-page-')[1]);
	});
	
	// Assign previous and next button text depending on the language - We should use the translation for each languages from i18n.csv /
	// Assigner le texte pour le bouton pr�c�dent et suivant d�pendant du langage - Nous devrions utiliser les traductions pour chaque langage dans i18n.csv
	var previousText = $('html').attr('lang') === "en" ? 'Previous' : 'Pr&eacute;c&eacute;dent';
	var nextText = $('html').attr('lang') === "en" ? 'Next' : 'Suivant';
	
	// Insert div with page number i.e. id="page-X" and a class to hide the page if not selected /
	// Ins�rer un div avec le num�ro de la page i.e. id="page-X" et une classe pour cacher la page si elle n'est pas s�lectionn�e
	for(var i = 0; i < divs.length; i += numberOfItemOnPage) {
	  pageCount++;
	  divs.slice(i, i+numberOfItemOnPage).wrapAll("<div class='hide-page' id='page-"+pageCount+"'></div>");
	}
	
	// Setup for simplePagination.js plugin / Configuration du plugiciel simplePagination.js
	$(function() {
		$('.page-selector').pagination({
			items: pageCount,
			itemsOnPage: 1,
			cssStyle: 'light-theme',
			prevText: previousText,
			nextText: nextText,
			displayedPages: 3,
			edges: 1,
			onPageClick: function(pageNumber){click(pageNumber)},
			onInit: function(pageNumber){click('1')}
		});
	});

});